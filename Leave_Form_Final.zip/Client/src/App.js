// import { BrowserRouter, Route, Routes } from "react-router-dom";
// import {BrowserRouter as Router,Switch,Route,Redirect,} from "react-router-dom";
// import Home from "./Home";
// import Admin from "./components/admin";
// import "./styles.css";

//  function App() {
//   return (

//     <>
//     <Router>
//       <Switch>
        
//         <Route exact path="/" component={Home} />
          
     
//         <Route path="/admin" component={About} />
          
    
//         {/* <Route path="/contactus" component={ContactUs} /> */}
          
       
//         {/* <Redirect to="/" /> */}
//       </Switch>
//     </Router>
//   </>
//     // <BrowserRouter>
//     //   <Routes>
//     //     <Route path="/" element={<Home />} />
//     //     <Route path="./components/admin.js" element={<Admin />} />
//     //   </Routes>
//     // </BrowserRouter>
//   );
// }
// export default App;


